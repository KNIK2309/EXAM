﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace Practice1.Models
{
    public class LoginModel
    {
        [Display(Name ="Login ID")]
        [Required(ErrorMessage ="Please Enter Login ID")]
        public int CustomerID { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "Please Enter Password")]
        [DataType(DataType.Password)]
        public string CustomerPassword { get; set; }
    }
}