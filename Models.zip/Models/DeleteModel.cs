﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace Practice1.Models
{
    public class DeleteModel
    {
        [Display(Name ="Enter ID")]
        [Required(ErrorMessage ="Please enter ID")]
        public int CakeID { get; set; }
    }
}