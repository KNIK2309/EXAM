﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace Practice1.Models
{
    public class UpdateModel
    {
        [Display(Name = "CakeID")]
        public int CakeID { get; set; }

        [Display(Name = "Cake Name")]
        [Required(ErrorMessage = "Please Enter Cake Name")]
        public string CakeName { get; set; }

        [Display(Name = "Cake Price")]
        [Required(ErrorMessage = "Please Enter Cake Price")]
        public int CakePrice { get; set; }

        [Display(Name = "Cake Weight")]
        [Required(ErrorMessage = "Please Enter Cake Weight")]
        public double CakeWeight { get; set; }
    }
}