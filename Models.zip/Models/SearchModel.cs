﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace Practice1.Models
{
    public class SearchModel
    {
        [Display(Name ="Search Key")]
        public string Key { get; set; }
        [Display(Name ="Search Result:")]
        public List<CakeModel> list { get; set; }
    }
}