﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Practice1.Models
{
    public class CakeDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr1"].ConnectionString);

        public int AddCake(CakeModel model)
        {
            try
            {
                SqlCommand add = new SqlCommand("p_add",con);
                add.CommandType = CommandType.StoredProcedure;
                add.Parameters.AddWithValue("@name", model.CakeName);
                add.Parameters.AddWithValue("@price", model.CakePrice);
                add.Parameters.AddWithValue("@weight", model.CakeWeight);
                add.Parameters.AddWithValue("@imgaddr", model.CakeImageAddr);
                SqlParameter p = new SqlParameter();
                p.Direction = ParameterDirection.ReturnValue;
                add.Parameters.Add(p);
                con.Open();
                add.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(p.Value);
                return id;
            }
            catch(Exception exp)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool Login(LoginModel model)
        {
            try
            {
                SqlCommand add = new SqlCommand("p_login", con);
                add.CommandType = CommandType.StoredProcedure;
                add.Parameters.AddWithValue("@id", model.CustomerID);
                add.Parameters.AddWithValue("@pass", model.CustomerPassword);

                SqlParameter p = new SqlParameter();
                p.Direction = ParameterDirection.ReturnValue;
                add.Parameters.Add(p);
                con.Open();
                add.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(p.Value);
                return count > 0;

            }
            catch(Exception exp)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool Update(UpdateModel model)
        {
            try
            {
                SqlCommand update = new SqlCommand("p_update", con);
                update.CommandType = CommandType.StoredProcedure;
                update.Parameters.AddWithValue("@id",model.CakeID);
                update.Parameters.AddWithValue("@name", model.CakeName);
                update.Parameters.AddWithValue("@price", model.CakePrice);
                update.Parameters.AddWithValue("@weight", model.CakeWeight);

                SqlParameter p = new SqlParameter();
                p.Direction = ParameterDirection.ReturnValue;
                update.Parameters.Add(p);
                con.Open();
                update.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(p.Value);
                return count > 0;
            }
            catch (Exception exp)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        } 

        public string Delete(DeleteModel model)
        {
            SqlCommand delete = new SqlCommand("p_delete", con);
            delete.CommandType = CommandType.StoredProcedure;
            delete.Parameters.AddWithValue("@id", model.CakeID);

            SqlParameter p = new SqlParameter();
            p.Direction = ParameterDirection.ReturnValue;
            delete.Parameters.Add(p);
            con.Open();
            delete.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(p.Value);
            if (count > 0)
            {
                return "Cake Deleted";
            }
            else
            {
                return "Cake ID not found";
            }
        }

        public List<CakeModel> Search(SearchModel model)
        {
            SqlCommand search = new SqlCommand("p_search", con);
            search.CommandType = CommandType.StoredProcedure;
            search.Parameters.AddWithValue("@key", model.Key);

            con.Open();
            SearchModel a = new SearchModel();
            SqlDataReader dr = search.ExecuteReader();
            while (dr.Read())
            {
                CakeModel cake = new CakeModel();
                cake.CakeID = dr.GetInt32(0);
                cake.CakeName = dr.GetString(1);
                cake.CakePrice = dr.GetInt32(2);
                cake.CakeWeight = (double)dr.GetDecimal(3);
                cake.CakeImageAddr = dr.GetString(4);
                a.list.Add(cake);
            }

            con.Close();
            return a.list;
        }
    }
}