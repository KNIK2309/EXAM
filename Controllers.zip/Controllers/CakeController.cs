﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Practice1.Models;
namespace Practice1.Controllers
{
    public class CakeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                CakeDAL dal = new CakeDAL();
                if (dal.Login(model))
                {
                    return RedirectToAction("Index", "Cake");
                }
                else
                {
                    ViewBag.msg = "Invalid ID or Password";
                }
            }
            return View();
        }

        [HttpGet]
        public ActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Add(CakeModel model)
        {
            if (ModelState.IsValid)
            {
                model.CakeImageAddr = "/Images/" + Guid.NewGuid() + ".jpg";
                model.CakeImage.SaveAs(Server.MapPath(model.CakeImageAddr));
                CakeDAL dal = new CakeDAL();
                int count = dal.AddCake(model);
                if (count > 0)
                {
                    ModelState.Clear();
                    ViewBag.msg = "Cake Added...";
                }
            }
            return View();
        }
        [HttpGet]
        public ActionResult Update()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Update(UpdateModel model)
        {
            if (ModelState.IsValid)
            {
                CakeDAL dal = new CakeDAL();
                if (dal.Update(model))
                {
                    ModelState.Clear();
                    ViewBag.msg = "Cake updated...";
                }
            }
            return View();
        }

        [HttpGet]
        public ActionResult Delete()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Delete(DeleteModel model)
        {
            CakeDAL dal = new CakeDAL();
            var status = dal.Delete(model);
            ViewBag.msg = status;
            return View();
        }
        [HttpGet]
        public ActionResult Search()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Search(SearchModel model)
        {
            CakeDAL dal = new CakeDAL();
            var cake = dal.Search(model);
            return View(cake);
        }
    }
}